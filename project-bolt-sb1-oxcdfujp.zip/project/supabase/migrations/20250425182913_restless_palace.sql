/*
  # Schema Update for Saudável & Feliz App

  This migration safely creates or updates the necessary tables and policies,
  checking for existence before creation to avoid conflicts.

  1. Tables
    - profiles
    - day_records
    - foods

  2. Security
    - RLS enabled on all tables
    - Policies for authenticated users
*/

-- Safely create or modify profiles table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS profiles (
    id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
    name text NOT NULL,
    partner_id uuid REFERENCES auth.users,
    total_points integer DEFAULT 0 NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS if not already enabled
ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;

-- Safely create policies for profiles
DO $$ BEGIN
  DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
  CREATE POLICY "Users can view their own profile"
    ON profiles
    FOR SELECT
    TO public
    USING (auth.uid() = id);

  DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
  CREATE POLICY "Users can update their own profile"
    ON profiles
    FOR UPDATE
    TO public
    USING (auth.uid() = id);
END $$;

-- Safely create or modify day_records table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS day_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
    date date NOT NULL,
    breakfast boolean DEFAULT false NOT NULL,
    lunch boolean DEFAULT false NOT NULL,
    dinner boolean DEFAULT false NOT NULL,
    perfect_day boolean DEFAULT false NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    penalty_applied boolean DEFAULT false NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    UNIQUE(user_id, date)
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS if not already enabled
ALTER TABLE IF EXISTS day_records ENABLE ROW LEVEL SECURITY;

-- Safely create policies for day_records
DO $$ BEGIN
  DROP POLICY IF EXISTS "Users can view their own day records" ON day_records;
  CREATE POLICY "Users can view their own day records"
    ON day_records
    FOR SELECT
    TO public
    USING (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can insert their own day records" ON day_records;
  CREATE POLICY "Users can insert their own day records"
    ON day_records
    FOR INSERT
    TO public
    WITH CHECK (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can update their own day records" ON day_records;
  CREATE POLICY "Users can update their own day records"
    ON day_records
    FOR UPDATE
    TO public
    USING (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can delete their own day records" ON day_records;
  CREATE POLICY "Users can delete their own day records"
    ON day_records
    FOR DELETE
    TO public
    USING (auth.uid() = user_id);
END $$;

-- Safely create or modify foods table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS foods (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
    name text NOT NULL,
    calories integer,
    points_required integer NOT NULL,
    image_url text,
    status text DEFAULT 'available' NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS if not already enabled
ALTER TABLE IF EXISTS foods ENABLE ROW LEVEL SECURITY;

-- Safely create policies for foods
DO $$ BEGIN
  DROP POLICY IF EXISTS "Users can view their own foods" ON foods;
  CREATE POLICY "Users can view their own foods"
    ON foods
    FOR SELECT
    TO public
    USING (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can insert their own foods" ON foods;
  CREATE POLICY "Users can insert their own foods"
    ON foods
    FOR INSERT
    TO public
    WITH CHECK (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can update their own foods" ON foods;
  CREATE POLICY "Users can update their own foods"
    ON foods
    FOR UPDATE
    TO public
    USING (auth.uid() = user_id);

  DROP POLICY IF EXISTS "Users can delete their own foods" ON foods;
  CREATE POLICY "Users can delete their own foods"
    ON foods
    FOR DELETE
    TO public
    USING (auth.uid() = user_id);
END $$;