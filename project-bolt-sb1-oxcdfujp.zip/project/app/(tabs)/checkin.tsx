import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { CircleCheck as CheckCircle, Circle as XCircle } from 'lucide-react-native';
import { MotivationalQuote } from '@/components/MotivationalQuote';
import { useAppData } from '@/hooks/useAppData';
import { useRouter } from 'expo-router';

export default function CheckInScreen() {
  const router = useRouter();
  const { couple, saveCheckIn, todaysCheckIn, getTodayFormatted } = useAppData();
  const [showMotivation, setShowMotivation] = useState(false);
  const [checkInStatus, setCheckInStatus] = useState({
    user1: todaysCheckIn?.user1Status || null,
    user2: todaysCheckIn?.user2Status || null,
  });

  useEffect(() => {
    if (todaysCheckIn) {
      setCheckInStatus({
        user1: todaysCheckIn.user1Status,
        user2: todaysCheckIn.user2Status,
      });
    }
  }, [todaysCheckIn]);

  const handleCheckIn = async (user, followed) => {
    const newStatus = { ...checkInStatus };
    newStatus[user] = followed;
    setCheckInStatus(newStatus);
    
    // Save to storage if both users have checked in
    if (newStatus.user1 !== null && newStatus.user2 !== null) {
      await saveCheckIn({
        date: getTodayFormatted(),
        user1Status: newStatus.user1,
        user2Status: newStatus.user2,
      });
      setShowMotivation(true);
      
      // Navigate back to home after a short delay
      setTimeout(() => {
        router.push('/(tabs)');
      }, 2000);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.dateContainer}>
        <Text style={styles.dateText}>{getTodayFormatted()}</Text>
      </View>
      
      {showMotivation && (
        <MotivationalQuote />
      )}
      
      <View style={styles.userContainer}>
        <Text style={styles.userName}>{couple.user1Name || 'Usuário 1'}</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[
              styles.checkButton,
              checkInStatus.user1 === true && styles.successButton,
              checkInStatus.user1 !== null && checkInStatus.user1 !== true && styles.disabledButton
            ]}
            onPress={() => handleCheckIn('user1', true)}
            disabled={checkInStatus.user1 !== null}
          >
            <CheckCircle color={checkInStatus.user1 === true ? '#FFF' : '#4CAF50'} size={24} />
            <Text style={[
              styles.buttonText,
              checkInStatus.user1 === true && styles.buttonTextLight
            ]}>Segui a dieta</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.checkButton,
              checkInStatus.user1 === false && styles.failButton,
              checkInStatus.user1 !== null && checkInStatus.user1 !== false && styles.disabledButton
            ]}
            onPress={() => handleCheckIn('user1', false)}
            disabled={checkInStatus.user1 !== null}
          >
            <XCircle color={checkInStatus.user1 === false ? '#FFF' : '#F44336'} size={24} />
            <Text style={[
              styles.buttonText,
              checkInStatus.user1 === false && styles.buttonTextLight
            ]}>Furei a dieta</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.divider} />
      
      <View style={styles.userContainer}>
        <Text style={styles.userName}>{couple.user2Name || 'Usuário 2'}</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[
              styles.checkButton,
              checkInStatus.user2 === true && styles.successButton,
              checkInStatus.user2 !== null && checkInStatus.user2 !== true && styles.disabledButton
            ]}
            onPress={() => handleCheckIn('user2', true)}
            disabled={checkInStatus.user2 !== null}
          >
            <CheckCircle color={checkInStatus.user2 === true ? '#FFF' : '#4CAF50'} size={24} />
            <Text style={[
              styles.buttonText,
              checkInStatus.user2 === true && styles.buttonTextLight
            ]}>Segui a dieta</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.checkButton,
              checkInStatus.user2 === false && styles.failButton,
              checkInStatus.user2 !== null && checkInStatus.user2 !== false && styles.disabledButton
            ]}
            onPress={() => handleCheckIn('user2', false)}
            disabled={checkInStatus.user2 !== null}
          >
            <XCircle color={checkInStatus.user2 === false ? '#FFF' : '#F44336'} size={24} />
            <Text style={[
              styles.buttonText,
              checkInStatus.user2 === false && styles.buttonTextLight
            ]}>Furei a dieta</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.infoContainer}>
        <Text style={styles.infoText}>Se ambos seguirem a dieta: +10 pontos</Text>
        <Text style={styles.infoText}>Se um furar a dieta: -10 pontos</Text>
        <Text style={styles.infoText}>Se não fizer check-in: Dia perdido</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  dateContainer: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    margin: 16,
    alignItems: 'center',
  },
  dateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  userContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  checkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F5F5',
    padding: 12,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  buttonText: {
    marginLeft: 8,
    fontWeight: '500',
    fontSize: 16,
  },
  buttonTextLight: {
    color: '#FFFFFF',
  },
  successButton: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  failButton: {
    backgroundColor: '#F44336',
    borderColor: '#F44336',
  },
  disabledButton: {
    opacity: 0.5,
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  infoContainer: {
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 16,
  },
  infoText: {
    fontSize: 14,
    color: '#2E7D32',
    marginBottom: 8,
  },
});