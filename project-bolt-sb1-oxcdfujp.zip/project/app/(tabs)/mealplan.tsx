import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { CreditCard as Edit, Check } from 'lucide-react-native';
import { useAppData } from '@/hooks/useAppData';

export default function MealPlanScreen() {
  const { mealPlan, saveMealPlan } = useAppData();
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(mealPlan || '');

  const handleSaveMealPlan = () => {
    saveMealPlan(editText);
    setIsEditing(false);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Plano Alimentar do Casal</Text>
          {!isEditing && (
            <TouchableOpacity style={styles.editButton} onPress={() => setIsEditing(true)}>
              <Edit size={20} color="#4CAF50" />
            </TouchableOpacity>
          )}
          {isEditing && (
            <TouchableOpacity style={styles.saveButton} onPress={handleSaveMealPlan}>
              <Check size={20} color="#FFFFFF" />
            </TouchableOpacity>
          )}
        </View>
        
        <View style={styles.mealPlanContainer}>
          {isEditing ? (
            <TextInput
              style={styles.textInput}
              value={editText}
              onChangeText={setEditText}
              multiline
              placeholder="Insira seu plano alimentar aqui..."
              textAlignVertical="top"
            />
          ) : (
            <Text style={styles.mealPlanText}>
              {mealPlan || 'Nenhum plano alimentar cadastrado. Clique no botão de editar para adicionar.'}
            </Text>
          )}
        </View>
        
        <View style={styles.infoContainer}>
          <Text style={styles.infoTitle}>Dicas para seu plano alimentar:</Text>
          <Text style={styles.infoText}>• Mantenha um horário regular para as refeições</Text>
          <Text style={styles.infoText}>• Inclua proteínas em todas as refeições</Text>
          <Text style={styles.infoText}>• Priorize alimentos naturais e evite ultraprocessados</Text>
          <Text style={styles.infoText}>• Beba pelo menos 2 litros de água por dia</Text>
          <Text style={styles.infoText}>• Faça pequenas mudanças sustentáveis na dieta</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  editButton: {
    padding: 8,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 8,
    borderRadius: 20,
  },
  mealPlanContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    minHeight: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginBottom: 24,
  },
  mealPlanText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#333333',
  },
  textInput: {
    fontSize: 16,
    lineHeight: 24,
    color: '#333333',
    minHeight: 180,
  },
  infoContainer: {
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#4CAF50',
    marginBottom: 8,
  },
});