import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import { CoupleProfile } from '@/components/CoupleProfile';
import { WeeklyCalendar } from '@/components/WeeklyCalendar';
import { PointsDisplay } from '@/components/PointsDisplay';
import { WeeklyHistory } from '@/components/WeeklyHistory';
import { useAppData } from '@/hooks/useAppData';

export default function HomeScreen() {
  const isFocused = useIsFocused();
  const { couple, points, checkIns } = useAppData();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isFocused) {
      // Refresh data when screen is focused
      setIsLoading(false);
    }
  }, [isFocused]);

  if (isLoading) {
    return (
      <View style={styles.center}>
        <Text>Carregando...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.logoContainer}>
        <Image 
          source={{ uri: 'https://i.imgur.com/kJqUNGt.png' }} 
          style={styles.logo} 
          resizeMode="contain"
        />
      </View>
      
      <CoupleProfile couple={couple} />
      
      <PointsDisplay points={points} />
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Progresso da Semana</Text>
        <WeeklyCalendar checkIns={checkIns} />
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Histórico</Text>
        <WeeklyHistory history={checkIns} couple={couple} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginVertical: 16,
  },
  logo: {
    width: 200,
    height: 100,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 12,
  },
});