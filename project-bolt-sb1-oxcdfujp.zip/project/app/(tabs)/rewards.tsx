import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput, Image, ScrollView } from 'react-native';
import { Plus, CreditCard as Edit, Trash, X } from 'lucide-react-native';
import { PointsDisplay } from '@/components/PointsDisplay';
import { useAppData } from '@/hooks/useAppData';

export default function RewardsScreen() {
  const { rewards, points, addReward, editReward, deleteReward, redeemReward } = useAppData();
  const [modalVisible, setModalVisible] = useState(false);
  const [editingReward, setEditingReward] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    points: '',
  });

  const handleAddReward = () => {
    setEditingReward(null);
    setFormData({
      name: '',
      imageUrl: '',
      points: '',
    });
    setModalVisible(true);
  };

  const handleEditReward = (reward) => {
    setEditingReward(reward);
    setFormData({
      name: reward.name,
      imageUrl: reward.imageUrl,
      points: reward.points.toString(),
    });
    setModalVisible(true);
  };

  const handleSaveReward = () => {
    const rewardData = {
      ...formData,
      points: parseInt(formData.points) || 0,
    };

    if (editingReward) {
      editReward({ ...editingReward, ...rewardData });
    } else {
      addReward(rewardData);
    }

    setModalVisible(false);
  };

  const handleDeleteReward = (id) => {
    deleteReward(id);
  };

  const handleRedeemReward = (reward) => {
    redeemReward(reward.id);
  };

  const renderRewardItem = ({ item }) => (
    <View style={styles.rewardCard}>
      <View style={styles.rewardHeader}>
        <Text style={styles.rewardName}>{item.name}</Text>
        <View style={styles.rewardActions}>
          <TouchableOpacity onPress={() => handleEditReward(item)} style={styles.actionButton}>
            <Edit size={18} color="#4CAF50" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDeleteReward(item.id)} style={styles.actionButton}>
            <Trash size={18} color="#F44336" />
          </TouchableOpacity>
        </View>
      </View>
      
      {item.imageUrl ? (
        <Image source={{ uri: item.imageUrl }} style={styles.rewardImage} />
      ) : (
        <View style={styles.noImage}>
          <Text style={styles.noImageText}>Sem imagem</Text>
        </View>
      )}
      
      <View style={styles.rewardFooter}>
        <Text style={styles.pointsText}>{item.points} pontos</Text>
        <TouchableOpacity 
          style={[
            styles.redeemButton,
            points < item.points && styles.disabledButton
          ]}
          disabled={points < item.points}
          onPress={() => handleRedeemReward(item)}
        >
          <Text style={styles.redeemButtonText}>
            {points >= item.points ? 'Resgatar' : 'Pontos insuficientes'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <PointsDisplay points={points} />
      
      <View style={styles.header}>
        <Text style={styles.title}>Recompensas Alimentares</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleAddReward}>
          <Plus size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
      
      {rewards.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            Nenhuma recompensa cadastrada. Adicione sua primeira recompensa!
          </Text>
        </View>
      ) : (
        <FlatList
          data={rewards}
          keyExtractor={(item) => item.id}
          renderItem={renderRewardItem}
          contentContainerStyle={styles.list}
        />
      )}
      
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingReward ? 'Editar Recompensa' : 'Nova Recompensa'}
              </Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <X size={24} color="#333" />
              </TouchableOpacity>
            </View>
            
            <ScrollView>
              <View style={styles.formGroup}>
                <Text style={styles.label}>Nome da comida</Text>
                <TextInput
                  style={styles.input}
                  value={formData.name}
                  onChangeText={(text) => setFormData({ ...formData, name: text })}
                  placeholder="Ex: Pizza"
                />
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>URL da imagem</Text>
                <TextInput
                  style={styles.input}
                  value={formData.imageUrl}
                  onChangeText={(text) => setFormData({ ...formData, imageUrl: text })}
                  placeholder="https://..."
                />
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>Pontos necessários</Text>
                <TextInput
                  style={styles.input}
                  value={formData.points}
                  onChangeText={(text) => setFormData({ ...formData, points: text })}
                  placeholder="100"
                  keyboardType="numeric"
                />
              </View>
              
              <TouchableOpacity 
                style={styles.saveButton} 
                onPress={handleSaveReward}
                disabled={!formData.name || !formData.points}
              >
                <Text style={styles.saveButtonText}>Salvar</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  addButton: {
    backgroundColor: '#4CAF50',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  list: {
    padding: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
  },
  rewardCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  rewardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  rewardName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  rewardActions: {
    flexDirection: 'row',
  },
  actionButton: {
    marginLeft: 12,
  },
  rewardImage: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    marginBottom: 12,
  },
  noImage: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  noImageText: {
    color: '#757575',
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pointsText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  redeemButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  disabledButton: {
    backgroundColor: '#BDBDBD',
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    padding: 12,
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});