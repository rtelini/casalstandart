import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useAppData } from '@/hooks/useAppData';
import { useRouter } from 'expo-router';

export default function SettingsScreen() {
  const router = useRouter();
  const { couple, saveCouple, resetData } = useAppData();
  const [names, setNames] = useState({
    user1Name: couple.user1Name || 'Usuário 1',
    user2Name: couple.user2Name || 'Usuário 2',
  });

  const handleSaveNames = async () => {
    await saveCouple({
      user1Name: names.user1Name.trim() || 'Usuário 1',
      user2Name: names.user2Name.trim() || 'Usuário 2',
    });
    Alert.alert('Sucesso', 'Nomes atualizados com sucesso!');
    
    // Navigate back to home to see the changes
    router.push('/(tabs)');
  };

  const handleResetData = () => {
    Alert.alert(
      'Resetar Dados',
      'Tem certeza que deseja resetar todos os dados do aplicativo? Esta ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Resetar', 
          style: 'destructive',
          onPress: async () => {
            await resetData();
            Alert.alert('Sucesso', 'Todos os dados foram resetados.');
            router.push('/(tabs)');
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Perfis do Casal</Text>
        <View style={styles.profilesContainer}>
          <View style={styles.profileInputContainer}>
            <Text style={styles.label}>Nome do Usuário 1</Text>
            <TextInput
              style={styles.input}
              value={names.user1Name}
              onChangeText={(text) => setNames({ ...names, user1Name: text })}
              placeholder="Usuário 1"
            />
          </View>
          
          <View style={styles.profileInputContainer}>
            <Text style={styles.label}>Nome do Usuário 2</Text>
            <TextInput
              style={styles.input}
              value={names.user2Name}
              onChangeText={(text) => setNames({ ...names, user2Name: text })}
              placeholder="Usuário 2"
            />
          </View>
          
          <TouchableOpacity style={styles.saveButton} onPress={handleSaveNames}>
            <Text style={styles.saveButtonText}>Salvar Alterações</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Sobre o Aplicativo</Text>
        <View style={styles.aboutContainer}>
          <Text style={styles.aboutTitle}>Saudável & Feliz</Text>
          <Text style={styles.aboutVersion}>Versão 1.0.0</Text>
          <Text style={styles.aboutDescription}>
            Aplicativo para casais que querem emagrecer juntos, através de um sistema
            de pontuação, check-ins e recompensas por manter a dieta.
          </Text>
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Gerenciamento de Dados</Text>
        <TouchableOpacity style={styles.resetButton} onPress={handleResetData}>
          <Text style={styles.resetButtonText}>Resetar Todos os Dados</Text>
        </TouchableOpacity>
        <Text style={styles.resetInfo}>
          Isso irá apagar todos os dados, incluindo perfis, pontos, check-ins e recompensas.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 16,
  },
  profilesContainer: {
    marginBottom: 8,
  },
  profileInputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    padding: 12,
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  aboutContainer: {
    alignItems: 'center',
  },
  aboutTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 4,
  },
  aboutVersion: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 16,
  },
  aboutDescription: {
    fontSize: 14,
    color: '#333333',
    textAlign: 'center',
    lineHeight: 22,
  },
  resetButton: {
    backgroundColor: '#F44336',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  resetButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  resetInfo: {
    fontSize: 12,
    color: '#757575',
    textAlign: 'center',
  },
});