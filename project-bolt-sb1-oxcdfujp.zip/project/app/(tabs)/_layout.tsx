import { Tabs } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { Heart, CircleCheck as CheckCircle, Gift, Utensils, Settings } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#4CAF50',
        tabBarInactiveTintColor: '#78909C',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#E0E0E0',
          height: 60,
          paddingBottom: 10,
          paddingTop: 10,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '500',
        },
        headerStyle: {
          backgroundColor: '#4CAF50',
        },
        headerTintColor: '#FFFFFF',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Início',
          tabBarIcon: ({ color, size }) => <Heart size={size} color={color} />,
          headerTitle: 'Saudável & Feliz',
        }}
      />
      <Tabs.Screen
        name="checkin"
        options={{
          title: 'Check-in',
          tabBarIcon: ({ color, size }) => <CheckCircle size={size} color={color} />,
          headerTitle: 'Check-in Diário',
        }}
      />
      <Tabs.Screen
        name="rewards"
        options={{
          title: 'Recompensas',
          tabBarIcon: ({ color, size }) => <Gift size={size} color={color} />,
          headerTitle: 'Recompensas',
        }}
      />
      <Tabs.Screen
        name="mealplan"
        options={{
          title: 'Dieta',
          tabBarIcon: ({ color, size }) => <Utensils size={size} color={color} />,
          headerTitle: 'Plano Alimentar',
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Ajustes',
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
          headerTitle: 'Configurações',
        }}
      />
    </Tabs>
  );
}