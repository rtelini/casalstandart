import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

// Types
interface Couple {
  user1Name: string;
  user2Name: string;
}

interface CheckIn {
  date: string;
  user1Status: boolean | null;
  user2Status: boolean | null;
}

interface Reward {
  id: string;
  name: string;
  imageUrl: string;
  points: number;
}

// Storage Keys
const STORAGE_KEYS = {
  COUPLE: '@saudavel_feliz:couple',
  POINTS: '@saudavel_feliz:points',
  CHECK_INS: '@saudavel_feliz:check_ins',
  REWARDS: '@saudavel_feliz:rewards',
  MEAL_PLAN: '@saudavel_feliz:meal_plan',
};

export function useAppData() {
  const [couple, setCouple] = useState<Couple>({
    user1Name: 'Usuário 1',
    user2Name: 'Usuário 2',
  });
  const [points, setPoints] = useState<number>(0);
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [mealPlan, setMealPlan] = useState<string>('');
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // Load data on initial mount
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [coupleData, pointsData, checkInsData, rewardsData, mealPlanData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.COUPLE),
        AsyncStorage.getItem(STORAGE_KEYS.POINTS),
        AsyncStorage.getItem(STORAGE_KEYS.CHECK_INS),
        AsyncStorage.getItem(STORAGE_KEYS.REWARDS),
        AsyncStorage.getItem(STORAGE_KEYS.MEAL_PLAN),
      ]);
      
      if (coupleData) setCouple(JSON.parse(coupleData));
      if (pointsData) setPoints(JSON.parse(pointsData));
      if (checkInsData) setCheckIns(JSON.parse(checkInsData));
      if (rewardsData) setRewards(JSON.parse(rewardsData));
      if (mealPlanData) setMealPlan(mealPlanData);
      
      setIsLoaded(true);
    } catch (error) {
      console.error('Error loading data:', error);
      setIsLoaded(true);
    }
  };

  // Save couple data
  const saveCouple = async (coupleData: Couple) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.COUPLE, JSON.stringify(coupleData));
      setCouple(coupleData);
    } catch (error) {
      console.error('Error saving couple data:', error);
      throw error;
    }
  };

  // Get today's date in DD/MM/YYYY format
  const getTodayFormatted = () => {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Get today's check-in if exists
  const getTodaysCheckIn = () => {
    const today = getTodayFormatted();
    return checkIns.find(checkIn => checkIn.date === today);
  };

  // Save check-in data
  const saveCheckIn = async (checkIn: CheckIn) => {
    try {
      // Check if this date already exists
      const existingIndex = checkIns.findIndex(ci => ci.date === checkIn.date);
      let newCheckIns = [...checkIns];
      
      if (existingIndex >= 0) {
        // Update existing check-in
        newCheckIns[existingIndex] = checkIn;
      } else {
        // Add new check-in
        newCheckIns = [...checkIns, checkIn];
      }
      
      await AsyncStorage.setItem(STORAGE_KEYS.CHECK_INS, JSON.stringify(newCheckIns));
      setCheckIns(newCheckIns);
      
      // Update points
      await updatePointsForCheckIn(checkIn);
    } catch (error) {
      console.error('Error saving check-in:', error);
      throw error;
    }
  };

  // Update points based on check-in results
  const updatePointsForCheckIn = async (checkIn: CheckIn) => {
    try {
      let pointsChange = 0;
      
      // Both followed the diet: +10 points
      if (checkIn.user1Status === true && checkIn.user2Status === true) {
        pointsChange = 10;
      }
      // At least one broke the diet: -10 points
      else if (checkIn.user1Status === false || checkIn.user2Status === false) {
        pointsChange = -10;
      }
      
      // Don't go below zero
      const newPoints = Math.max(0, points + pointsChange);
      await AsyncStorage.setItem(STORAGE_KEYS.POINTS, JSON.stringify(newPoints));
      setPoints(newPoints);
    } catch (error) {
      console.error('Error updating points:', error);
      throw error;
    }
  };

  // Rewards management
  const addReward = async (reward: Omit<Reward, 'id'>) => {
    try {
      const newReward = {
        ...reward,
        id: uuidv4(),
      };
      
      const newRewards = [...rewards, newReward];
      await AsyncStorage.setItem(STORAGE_KEYS.REWARDS, JSON.stringify(newRewards));
      setRewards(newRewards);
    } catch (error) {
      console.error('Error adding reward:', error);
      throw error;
    }
  };

  const editReward = async (updatedReward: Reward) => {
    try {
      const index = rewards.findIndex(r => r.id === updatedReward.id);
      if (index === -1) return;
      
      const newRewards = [...rewards];
      newRewards[index] = updatedReward;
      
      await AsyncStorage.setItem(STORAGE_KEYS.REWARDS, JSON.stringify(newRewards));
      setRewards(newRewards);
    } catch (error) {
      console.error('Error editing reward:', error);
      throw error;
    }
  };

  const deleteReward = async (id: string) => {
    try {
      const newRewards = rewards.filter(r => r.id !== id);
      await AsyncStorage.setItem(STORAGE_KEYS.REWARDS, JSON.stringify(newRewards));
      setRewards(newRewards);
    } catch (error) {
      console.error('Error deleting reward:', error);
      throw error;
    }
  };

  const redeemReward = async (id: string) => {
    try {
      const reward = rewards.find(r => r.id === id);
      if (!reward || points < reward.points) return;
      
      // Deduct points
      const newPoints = points - reward.points;
      await AsyncStorage.setItem(STORAGE_KEYS.POINTS, JSON.stringify(newPoints));
      setPoints(newPoints);
    } catch (error) {
      console.error('Error redeeming reward:', error);
      throw error;
    }
  };

  // Meal plan management
  const saveMealPlan = async (plan: string) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.MEAL_PLAN, plan);
      setMealPlan(plan);
    } catch (error) {
      console.error('Error saving meal plan:', error);
      throw error;
    }
  };

  // Reset all data
  const resetData = async () => {
    try {
      // Remove all data from AsyncStorage
      await AsyncStorage.multiRemove([
        STORAGE_KEYS.COUPLE,
        STORAGE_KEYS.POINTS,
        STORAGE_KEYS.CHECK_INS,
        STORAGE_KEYS.REWARDS,
        STORAGE_KEYS.MEAL_PLAN,
      ]);
      
      // Reset all state to initial values
      setCouple({ user1Name: 'Usuário 1', user2Name: 'Usuário 2' });
      setPoints(0);
      setCheckIns([]);
      setRewards([]);
      setMealPlan('');
    } catch (error) {
      console.error('Error resetting data:', error);
      throw error;
    }
  };

  return {
    couple,
    points,
    checkIns,
    rewards,
    mealPlan,
    isLoaded,
    saveCouple,
    saveCheckIn,
    addReward,
    editReward,
    deleteReward,
    redeemReward,
    saveMealPlan,
    resetData,
    getTodayFormatted,
    todaysCheckIn: getTodaysCheckIn(),
  };
}