const motivationalQuotes = [
  "Mais um dia vencido!",
  "Juntos até a pizza valer a pena!",
  "Vai ter sorvete no final, força!",
  "Determinação de casal é imbatível!",
  "A dieta é difícil, mas vocês são mais fortes!",
  "Cada dia na dieta é um passo para o objetivo!",
  "Pensem na roupa que vai servir no final!",
  "O único treino ruim é aquele que não foi feito!",
  "Disciplina é liberdade!",
  "Juntos, vocês conseguem qualquer coisa!",
  "A motivação é o que te faz começar. O hábito é o que te faz continuar.",
  "Sua saúde é um investimento, não uma despesa.",
  "Não desista do que você realmente quer!",
  "O sucesso de vocês será proporcional ao esforço!",
  "Um casal que se cuida, permanece unido por mais tempo!"
];

export function getRandomMotivationalQuote() {
  const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
  return motivationalQuotes[randomIndex];
}