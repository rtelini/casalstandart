import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Star } from 'lucide-react-native';

interface PointsDisplayProps {
  points: number;
}

export function PointsDisplay({ points }: PointsDisplayProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Star size={24} color="#FFD700" fill="#FFD700" />
      </View>
      <View style={styles.pointsContainer}>
        <Text style={styles.title}>Pontuação do Casal</Text>
        <Text style={styles.points}>{points} pontos</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  pointsContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    color: '#E8F5E9',
  },
  points: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});