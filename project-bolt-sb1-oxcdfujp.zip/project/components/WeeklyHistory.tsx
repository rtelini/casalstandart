import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { Check, X, TriangleAlert as AlertTriangle } from 'lucide-react-native';

interface CheckIn {
  date: string;
  user1Status: boolean | null;
  user2Status: boolean | null;
}

interface WeeklyHistoryProps {
  history: CheckIn[];
  couple: {
    user1Name: string;
    user2Name: string;
  };
}

export function WeeklyHistory({ history, couple }: WeeklyHistoryProps) {
  // Sort the history by date (most recent first)
  const sortedHistory = [...history].sort((a, b) => {
    const dateA = new Date(a.date.split('/').reverse().join('-'));
    const dateB = new Date(b.date.split('/').reverse().join('-'));
    return dateB.getTime() - dateA.getTime();
  });
  
  // Take only the last 7 days
  const recentHistory = sortedHistory.slice(0, 7);
  
  const getStatusIcon = (status: boolean | null) => {
    if (status === true) {
      return <Check size={16} color="#4CAF50" />;
    } else if (status === false) {
      return <X size={16} color="#F44336" />;
    } else {
      return <AlertTriangle size={16} color="#FFC107" />;
    }
  };
  
  const getDayStatus = (item: CheckIn) => {
    if (item.user1Status === true && item.user2Status === true) {
      return <View style={[styles.statusDot, styles.successDot]} />;
    } else if (item.user1Status === false && item.user2Status === false) {
      return <View style={[styles.statusDot, styles.failDot]} />;
    } else {
      return <View style={[styles.statusDot, styles.mixedDot]} />;
    }
  };
  
  const renderHistoryItem = ({ item }: { item: CheckIn }) => (
    <View style={styles.historyItem}>
      <View style={styles.dateContainer}>
        <Text style={styles.date}>{item.date}</Text>
        {getDayStatus(item)}
      </View>
      
      <View style={styles.userStatusContainer}>
        <View style={styles.userStatus}>
          <Text style={styles.userName}>{couple.user1Name || 'Usuário 1'}</Text>
          {getStatusIcon(item.user1Status)}
        </View>
        
        <View style={styles.userStatus}>
          <Text style={styles.userName}>{couple.user2Name || 'Usuário 2'}</Text>
          {getStatusIcon(item.user2Status)}
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {recentHistory.length === 0 ? (
        <Text style={styles.emptyText}>
          Ainda não há registros de check-in. Comece hoje!
        </Text>
      ) : (
        <FlatList
          data={recentHistory}
          keyExtractor={(item) => item.date}
          renderItem={renderHistoryItem}
          scrollEnabled={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  emptyText: {
    fontSize: 14,
    color: '#757575',
    textAlign: 'center',
    padding: 16,
  },
  historyItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginRight: 8,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  successDot: {
    backgroundColor: '#4CAF50',
  },
  failDot: {
    backgroundColor: '#F44336',
  },
  mixedDot: {
    backgroundColor: '#FFC107',
  },
  userStatusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  userStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: {
    fontSize: 14,
    color: '#757575',
    marginRight: 8,
  },
});