import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { getRandomMotivationalQuote } from '@/utils/motivationalQuotes';

export function MotivationalQuote() {
  const [quote, setQuote] = useState('');

  useEffect(() => {
    setQuote(getRandomMotivationalQuote());
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.quoteText}>{quote}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  quoteText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: '#2E7D32',
    textAlign: 'center',
  },
});