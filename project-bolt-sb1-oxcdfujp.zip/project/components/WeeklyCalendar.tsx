import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Check, X, TriangleAlert as AlertTriangle } from 'lucide-react-native';
import { getDaysOfCurrentWeek, formatDateShort } from '@/utils/dateUtils';

interface CheckIn {
  date: string;
  user1Status: boolean | null;
  user2Status: boolean | null;
}

interface WeeklyCalendarProps {
  checkIns: CheckIn[];
}

export function WeeklyCalendar({ checkIns }: WeeklyCalendarProps) {
  const weekDays = getDaysOfCurrentWeek();
  
  const getStatusForDay = (date: string) => {
    const checkIn = checkIns.find(ci => ci.date === date);
    
    if (!checkIn) {
      return null; // No check-in for this day
    }
    
    const { user1Status, user2Status } = checkIn;
    
    if (user1Status === true && user2Status === true) {
      return 'success';
    } else if (user1Status === false && user2Status === false) {
      return 'fail';
    } else {
      return 'mixed';
    }
  };

  return (
    <View style={styles.container}>
      {weekDays.map((day, index) => {
        const formattedDate = formatDateShort(day);
        const status = getStatusForDay(formattedDate);
        let statusColor = '#E0E0E0'; // default gray
        let IconComponent = null;
        
        if (status === 'success') {
          statusColor = '#4CAF50'; // green
          IconComponent = Check;
        } else if (status === 'fail') {
          statusColor = '#F44336'; // red
          IconComponent = X;
        } else if (status === 'mixed') {
          statusColor = '#FFC107'; // yellow
          IconComponent = AlertTriangle;
        }
        
        return (
          <View key={index} style={styles.dayContainer}>
            <Text style={styles.dayName}>{formattedDate.split('/')[0]}</Text>
            <View 
              style={[
                styles.statusCircle, 
                { backgroundColor: statusColor }
              ]}
            >
              {IconComponent && <IconComponent size={14} color="#FFFFFF" />}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayContainer: {
    alignItems: 'center',
  },
  dayName: {
    fontSize: 16,
    marginBottom: 8,
    color: '#333',
  },
  statusCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
});