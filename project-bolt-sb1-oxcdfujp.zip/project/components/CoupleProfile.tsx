import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Users } from 'lucide-react-native';

interface CoupleProfileProps {
  couple: {
    user1Name: string;
    user2Name: string;
  };
}

export function CoupleProfile({ couple }: CoupleProfileProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Users size={28} color="#4CAF50" />
      </View>
      <View style={styles.namesContainer}>
        <Text style={styles.title}>Casal</Text>
        <Text style={styles.names}>
          {couple.user1Name || 'Usuário 1'} & {couple.user2Name || 'Usuário 2'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    backgroundColor: '#E8F5E9',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  namesContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    color: '#757575',
  },
  names: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
});